
    $(function () {

      var element = $("#scroll"), display;

      $(window).scroll(function () {

        display = $(this).scrollTop() >= 100;

        display != element.css('opacity') && element.stop().animate({ 'opacity': display }, 200);

  });
  });

